# Pacotes
library(shiny)
library(plotly)
library(leaflet)
#library(d3plus) # devtools::install_github("jpmarindiaz/d3plus")
library(D3plusR)
library(DT) # Data tables
library(C3) # devtools::install_github("FrissAnalytics/shinyJsTutorials/widgets/C3")
library(spdep)
library(flexdashboard) # install.packages("flexdashboard", type = "source")
library(tidyverse)
library(stringi)
library(shinyBS) # Pelos botoes de popover e tooltip
library(shinythemes)

# Para definir a imagem
#setwd("C:/Users/renan/Desktop/Shiny Apps/ProjetoAppCrime")
#setwd("C:/Users/Windows 8.1/Desktop/Shiny Apps/ProjetoAppCrime")
#base_crime_pre <- read.csv("Base_Crimes_FEE.csv", header=T, sep=";")
#base_crime <- subset(base_crime_pre, !(Mun == "Pinto Bandeira" & Ano < 2013)) # Retira os dados que daram problemas depois
#mapa_rs <-  readOGR("C:/Users/renan/Desktop/Shiny Apps/Shapes", "43mu2500gsd", encoding='UTF-8', verbose = FALSE)
##mapa_rs <-  readOGR("C:/Users/Windows 8.1/Desktop/Shiny Apps", "43mu2500gsd", encoding='UTF-8', verbose = FALSE)

#load("C:/Users/renan/Desktop/Shiny Apps/ProjetoAppCrime/Imagem_AppCrime.Rdata")
#load("C:/Users/Windows 8.1/Desktop/Shiny Apps/ProjetoAppCrime/Imagem_AppCrime.Rdata")
#load("srv/shiny-server/crime/Imagem_AppCrime.Rdata")

#base_crime <- readRDS("BaseCrime_2016.rds") # Está em tibble
base_crime <- readRDS("base_crimevis_2016_pop_ok.rds") # Está em tibble
trad <- readRDS("tradutor_crimevis.rds")

base_crime %<>% # base_crime recebe base_crime
  merge(trad, by = "Crime") %>%
  select(-Crime) %>%
  rename(Crime = CrimeEng)

base_crime$Mun <- stri_conv(as.character(base_crime$Mun), "latin1", "UTF-8")
base_crime$Crime <- stri_conv(as.character(base_crime$Crime), "latin1", "UTF-8")

mapa_rs <- readRDS("MapaRS.rds")
mapa_rs@data$Nome_Munic <- stri_conv(as.character(mapa_rs@data$Nome_Munic), "latin1", "UTF-8")

cods_rmpa <- c(4300604,4300877,4301107,4303103,4303905,4304606,4304689,4305355,4306403,4306767,4307609,4307708,4309050,4309209,4309308,4310108,4310801,4312401,4313060,4313375,4313409,4314050,4314803,4314902,4316006,4317608,4318408,4318705,4319505,4319901,4320008,4321204,4322004,4323002)

options(shiny.sanitize.errors = FALSE)

# Definindo o UI
shinyUI(function(request){fluidPage(includeCSS("estilocrime.css"), htmlOutput("frame"), theme = shinytheme("cerulean"), tags$head(tags$script(src="tracking.js")), tags$head(tags$link(rel="shortcut icon", href="feeicon.ico")),
        tags$div(
  HTML("<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-1506603-5', 'auto');
  ga('send', 'pageview');

</script>
")
),
tags$style(type="text/css", # isso é para não mostrar nenhuma mensagem vermelha de erro!!
  ".shiny-output-error { visibility: hidden; }",
  ".shiny-output-error:before { visibility: hidden; }"
),

# Essa parte de baixo dá uma "empurradinha" pra direita o navbarheader pra aparecer o nome do app: https://stackoverflow.com/questions/9792849/how-to-insert-spaces-tabs-in-text-using-html-css
tags$style(type = 'text/css',

                           '.navbar-default .navbar-brand {
							 padding-left: 35px;
                           }'

                           ),  
  # Application title
  #titlePanel(paste0("- ",  "CrimeVis: Visualização da Criminalidade Anual no Rio Grande do Sul")),
  
  navbarPage(id = "main_page", "CrimeVis", # Navegação
             tabPanel(id = "presentation", "Presentation", #Apresentação
                      
                      sidebarLayout(
                        sidebarPanel(
                          h2("Economics and Statistics Foundation"),
                          p("The Siegfried Emanuel Heuser Economics and Statistics Foundation (FEE) is a research institution, linked to the Secretariat of Planning, Mobility and Regional Development of the Government of the State of Rio Grande do Sul."),
                          br(),
                          br(),
                          img(src = "fee_logo.png", height = 32, width = 132), 
                          img(src = "logoGoverno.png", height = 62, width = 92),
                          br(),
                          br(),
                          br(),
                          "Shiny is a product from ", 
                          span("RStudio", style = "color:blue"),".", 
                          br(), 
                          br(),
                          img(src = "bigorb.png", height = 82, width = 92)
                        ),
                        mainPanel(
                          h1("Visualization of annual crime in Rio Grande do Sul"),
                          p("The CrimeVis application is a product of the Economics and Statistics Foundation that presents, in an interactive and dynamic way, the crimes of the municipalities of Rio Grande do Sul (RS) with annual data provided by the Public Security Secretariat of RS (SSP-RS). Your raw data can be accessed either in the ",em("website")," of SSP-RS in this", 
                            a("link", href = "http://www.ssp.rs.gov.br/"), "or in FEEDADOS in this", a("link", href = "http://feedados.fee.tche.br/feedados/",".")),
                          br(),
                          p("CrimeVis was developed using Shiny. For an introduction and examples, access ",
                            a("Shiny homepage.", 
                              href = "http://www.rstudio.com/shiny")),
						  br(),
                          #p(em("Nota: Como os dados de criminalidade de 2016 já estão disponíveis, os dados populacionais de 2016 são as estimativas de 2015 neste aplicativo para o cálculo das taxas. Assim que as estimativas populacionais de 2016 forem calculadas, elas serão atualizadas no CrimeVis.")),						  
                          br(),
                          h2("App Features"),
                          p("* Visualize time series of municipalities and state by number of occurrences and rates."),
                          p("* Relate crimes in Bubble Plots and create groups of cities using K-Means."),
                          p("* Visualize data on maps in an interactive way, and calculate spatial autocorrelation of crimes."),
						  p("* Check the spatiotemporal evolution of the presence/absence of crimes through Markov Chains."),
                          p("* Get municipal representation in the state quickly and intuitively."),
                          p("* Perform quick searches on the database and ",em("download")," the dataset."),
                          br(),
                          h3("Contact for questions, suggestions or requests:"),
						  p("Renan Xavier Cortes ",
                            a("(CONTACT)", 
                              href = "http://www.fee.rs.gov.br/contato/", target="_blank"))
                          #p("Renan Xavier Cortes (renan@fee.tche.br)")
                          )
                      )),
             navbarMenu(title = "Time Series",
               tabPanel(id = "compare_crimes", "Compare Crimes",
                      
                      sidebarLayout(
                        sidebarPanel(
                          
                          selectInput('cidade_compara_crime', 'Choose a city', 
                                      as.character(unique(base_crime$Mun)),
                                      selected = "Porto Alegre"),
                          
                          selectizeInput('crimes_compara_crimes', 'Choose up to 5 crimes', 
                                      as.character(unique(base_crime$Crime)),
                                      selected = c("Homicide"),
                                      options = list(maxItems = 5,
                                                     placeholder = 'Select a list of crimes...')),
                          
                          radioButtons("tipo_dado_compara_crime", "Information Type:",
                                       c("Number of Occurrences" = "ocorre_radio_compara_crime",
                                         "Rate per 100,000 people" = "taxa_radio_compara_crime"))
                          
                        ),
                        
                        # Show the plots
                        mainPanel(
                          tabsetPanel(id = "tab_set_ts", type = "tabs", 
                                      tabPanel(id = "cities", "Cities", plotlyOutput("ts_compara_crime_cidades")), 
                                      tabPanel(id = "state", "State", plotlyOutput("ts_compara_crime_rs"))
                          )
                        )
                      )),
               tabPanel(id = "compare_cities", "Compare Cities",
                        
                        sidebarLayout(
                          sidebarPanel(
                            
                            selectizeInput('cidades_compara', 'Choose up to 5 cities', 
                                        as.character(unique(base_crime$Mun)),
                                        selected = c("Porto Alegre"),
                                        options = list(maxItems = 5,
                                                       placeholder = 'Select a list of cities...')),
                            
                            selectInput('crime_compara', 'Choose a crime', 
                                        as.character(unique(base_crime$Crime)),
										selected = "Robbery"),
                            
                            radioButtons("tipo_dado_compara_municipio", "Information Type:",
                                         c("Number of Occurrences" = "ocorre_radio_compara_municipio",
                                           "Rate per 100,000 people" = "taxa_radio_compara_municipio")),
                            
                            checkboxInput("checkbox_inclui_rs_rmpa_ts", label = "Include another series?", value = FALSE),
							
							conditionalPanel(condition = 'input.checkbox_inclui_rs_rmpa_ts',
                            radioButtons("radio_estado_rmpa", "Which Region?",
                                         c("Rio Grande do Sul state" = "radio_rs",
                                           "Metropolitan Region of Porto Alegre (capital)" = "radio_rmpa"
                                           ))
                            )
							
                            
                          ),
                          
                          # Show the plots
                          mainPanel(
                            plotlyOutput("ts_compara_cidades")
                          )
                        ))), 
             tabPanel(id = "relation", "Relation between crimes",
                                   sidebarLayout(
                                     sidebarPanel(
                                       
                                       sliderInput('ano_disp', 'Choose the year', 
                                                   min = min(base_crime$Ano),
                                                   max = max(base_crime$Ano),
                                                   value = max(base_crime$Ano),
                                                   step=1,
                                                   animate = animationOptions(interval = 1750, loop = TRUE), sep=""), # 1500
                                       
								       sliderInput('dispersao_mun_pop_control', "Population range:",
						                           min = 0,
						                           max = 1500000,
						                           value = range(c(0, 1500000)),
						                           step = 2500),
									   
                                       selectInput('crimex', 'Select the horizontal axis crime', 
                                                   as.character(unique(base_crime$Crime)),
                                                   selected = "Homicide"),
                                       
                                       selectInput('crimey', 'Select the vertical axis crime', 
                                                   as.character(unique(base_crime$Crime)),
                                                   selected = "Robbery"),
                                       
                                       radioButtons("tipo_dado_disp", "Information Type:",
                                                    c("Number of Occurrences" = "ocorre_radio_disp",
                                                      "Rate per 100,000 people" = "taxa_radio_disp")),

                                       fluidRow(
                                         column(8, checkboxInput("checkbox_kmeans", label = "Create groups of municipalities?", 
                                                                 value = FALSE)),
                                        column(4, bsButton("q_kmeans", label = "Help", icon = icon("info"),
                                                           style = "info", size = "medium")),
                                        bsPopover(id = "q_kmeans", title = "K-Means",
                                                 content = paste0("The groups of municipalities to be created follow the clustering algorithm called ", strong("K-Means"), ". This algorithm groups similar cities among themselves according to their distances between the chosen crimes. That is, municipalities that have similar occurrences or rates, will be in the same group. For more information see this ", 
                                                                  a("methodological link", 
                                                                    href = "https://www.coursera.org/learn/machine-learning/lecture/93VPG/k-means-algorithm",
                                                                    target="_blank"),"."),
                                                 placement = "right", 
                                                 trigger = "focus", # O 'click' só fechava quando clicava denovo 
                                                 options = list(container = "body")
                                       )),
                                       
                                       conditionalPanel(condition = 'input.checkbox_kmeans',
                                                        numericInput("n_grupos_kmeans", "Number of Groups:", 3, min = 2, max = 496)
                                                        )
                                       
                                     ),
                                     
                                     # Show the plots
                                     mainPanel(
                                       plotlyOutput("dispersao")
                                     )
                                   )),
             tabPanel(id = "maps", "Maps",
			 
			 mainPanel(width = 12,
                                tabsetPanel(id = "tab_set_maps", type = 'tabs',
                      tabPanel(id = "dynamic_maps", "Dynamic Maps",
                      
                      sidebarLayout(
                        sidebarPanel(
                          
                          sliderInput('ano_mapa', 'Choose the year', 
                                      min = min(base_crime$Ano),
                                      max = max(base_crime$Ano),
                                      value = max(base_crime$Ano),
                                      step=1,
                                      animate = animationOptions(interval = 1750, loop = TRUE), sep=""),
                          
                          conditionalPanel(condition = ("input.tipo_dado_mapa != 'pop_radio_mapa'"),
                                           selectInput('crime_mapa', 'Choose a crime', 
                                                       as.character(unique(base_crime$Crime)),
                                                       selected = "Homicide")),
                          
                          radioButtons("tipo_dado_mapa", "Information Type:",
                                       c("Number of Occurrences" = "ocorre_radio_mapa",
                                         "Rate per 100,000 people" = "taxa_radio_mapa",
                                         "Population" = "pop_radio_mapa")),
                          
                          conditionalPanel(condition = ("input.tipo_dado_mapa == 'pop_radio_mapa'"), 
                                           sliderInput("sens_mapa", "Map Sensitivity:", 
                                                       min=1.5, max=2.5, value=1.9)),
                          
                          fluidRow(
                            column(8, checkboxInput("checkbox_moran", label = "Calculate spatial autocorrelation?", 
                                                    value = FALSE)),
                            column(4, bsButton(inputId = "q_moran", label = "Help", icon = icon("info"),
                                   style = "info", size = "medium"),
                          bsPopover(id = "q_moran", title = "Spatial Autocorrelation",
                                    content = paste0("Spatial autocorrelation is a statistical measure that measures how much a municipality is affected by its neighbors and, for that, it is necessary to determine a neighborhood structure. The measure used is the ", strong("Moran´s I index"), " which ranges from -1 to 1. Indices close to 1 mean that neighboring municipalities have similar values. On the other hand, the value of -1 means that the criminal relationship is inverse, that is, high values ​​imply low values ​​of neighbors and vice versa. The value zero indicates absence of spatial autocorrelation. For more information see this ", 
                                                     a("methodological link", 
                                                       href = "http://www.leg.ufpr.br/lib/exe/fetch.php/disciplinas:cieg:intro-areas.pdf",
                                                       target="_blank"),"."),
                                    placement = "right", 
                                    trigger = "focus", # O 'click' só fechava quando clicava denovo 
                                    options = list(container = "body")
                          ))),
						  

                          
                          conditionalPanel(condition = 'input.checkbox_moran',
                                           selectInput('tipo_estrutura_espacial', "Neighborhood structure type:", 
                                                       choices = c("Municipalities bordering (queen type)", "Nearest neighbors (k-NN)"))),
                          
                          conditionalPanel(condition = 'input.tipo_estrutura_espacial == "Nearest neighbors (k-NN)"',
                                           conditionalPanel(condition = 'input.checkbox_moran',
                                           numericInput("n_vizinhos_moran", "Number of Neighbors:", 2, min = 1, max = 496))),
						  
						  br(),
						  bookmarkButton(id = "bookmark_maps",
								   label = "Share...",
								   icon = icon("share-alt"),
								   title = "Share this information!")
                          
                        ),
                        
                        # Show the plots
                        mainPanel(
                          leafletOutput("mapa_final"),
                          hr(),
                          conditionalPanel(condition = 'input.checkbox_moran',
                                           fluidRow(column(4,gaugeOutput("gauge_moran"),
										                     bsTooltip("gauge_moran", title = "Calculated spatial autocorrelation", placement = "top", 
                                                                     trigger = "hover",
                                                                     options = NULL)),
                                                    column(8,plotOutput("mapinha_grafo"))))
                        )
                      )),
					  
					  tabPanel(id = "markov", "Markov Chains",
                                
                                sidebarLayout(
                                  sidebarPanel(
                                    
                                    selectInput('crime_markov', 'Crime to be analyzed', 
                                                                 as.character(unique(base_crime$Crime)),
                                                                 selected = "Car Robbery"),
                                    
                                    sliderInput('anos_markov', "Analysis period:",
                                                min = min(base_crime$Ano),
                                                max = max(base_crime$Ano),
                                                value = range(c(min(base_crime$Ano), max(base_crime$Ano))),
                                                sep = ""), # Para remover o separador de milhar
                                    
                                    radioButtons("tipo_analise_markov", "Markovian Analysis Type:",
                                                 c("Temporal" = "radio_matriz_markov",
                                                   "Spatiotemporal" = "radio_matriz_markov_estratificada")),
												   
									conditionalPanel(condition = "input.tipo_analise_markov == 'radio_matriz_markov'",
                                    checkboxInput("checkbox_inclui_teste_temporal", label = "Perform temporal homogeneity test?", value = FALSE)),
                                    
                                    conditionalPanel(condition = "input.tipo_analise_markov == 'radio_matriz_markov'",
									conditionalPanel(condition = "input.checkbox_inclui_teste_temporal",
                                                     sliderInput('anos_markov_janela_1', "First time window of the test:",
                                                                 min = min(base_crime$Ano),
                                                                 max = max(base_crime$Ano),
                                                                 value = range(c(min(base_crime$Ano), floor(mean(c(min(base_crime$Ano), max(base_crime$Ano)))))),
                                                                 sep = ""),
                                                     sliderInput('anos_markov_janela_2', "Second time window of the test:",
                                                                 min = min(base_crime$Ano),
                                                                 max = max(base_crime$Ano),
                                                                 value = range(c(floor(mean(c(min(base_crime$Ano), max(base_crime$Ano)))), max(base_crime$Ano))),
                                                                 sep = ""))),
												   
									checkboxInput("checkbox_inclui_evolucao_instantaneo_markoviana", label = "Include annual instant evolution of Odds Ratio", value = FALSE),
									
									br(),
												   
									p('Inspired in Rey, Sergio J., Elizabeth A. Mack, and Julia Koschinsky. ', em('Exploratory space–time analysis of burglary patterns.'), 'Journal of Quantitative Criminology 28.3 (2012): 509-531.'),
									br(),
									bookmarkButton(id = "bookmark_chain",
                                               label = "Share...",
                                               icon = icon("share-alt"),
                                               title = "Share this information!")
                                    
                                    
                                  ),
                                  
                                  # Show the plots
                                  mainPanel(plotOutput("mapas_markov"), 
                                  conditionalPanel(condition = ("input.tipo_analise_markov == 'radio_matriz_markov'"),
                                            div(h3("Temporal Transition Probability Matrix"), align = "center"),
                                            div(tableOutput("tabela_markov_simples"), align = "center"),
                                            div(h4("Odds Ratio Table"), align = "center"),
                                            div(tableOutput("odds_ratio_simples"), align = "center"),
                                            br(),
                                            div(h4("Frequency Matrix and Independence Test"), align = "center"),
                                            fluidRow(column(8, tableOutput("tabela_bruta")),
                                                     div(column(4, h4("Chi-Square test"), br(), verbatimTextOutput("estatistica_chi")), align = "center")),
													 
											conditionalPanel(condition = "input.checkbox_inclui_teste_temporal",
                                            div(h4(textOutput('anos_janelas')), align = "center"),
                                            div(verbatimTextOutput("teste_chi_homog_temporal"), align = "center")),
													 
										    conditionalPanel(condition = 'input.checkbox_inclui_evolucao_instantaneo_markoviana', br(), br(), plotlyOutput("evolucao_odds_temporal"))),
													 
													 
								  
								  
                                  
                                  conditionalPanel(condition = ("input.tipo_analise_markov == 'radio_matriz_markov_estratificada'"),
                                                   div(h3("Spatiotemporal Transition Probability Matrix"), align = "center"),
                                                   div(tableOutput("tabela_markov_estratificada"), align = "center"),
                                                   fluidRow(column(8, div(h4("Odds Ratio Table"), align = "center"),
                                                   div(tableOutput("odds_ratio_estratificado"), align = "center")),
                                                   column(4, div(h4("Spatial Homogeneity Test"), align = "center"),
                                                   div(verbatimTextOutput("teste_chi_homog_spat"), align = "center"))),
												   
												   conditionalPanel(condition = 'input.checkbox_inclui_evolucao_instantaneo_markoviana', br(), br(), plotlyOutput("evolucao_odds_espaco_temporal"))
												   
												   )
                                  
                                  
                                )
                                )
                                
                                
                                )
                      
                      ))) # !
					  
					  ,
             
             tabPanel(id = "share", "Share in Rio Grande do Sul",
                      
                      sidebarLayout(
                        sidebarPanel(
                          
                          sliderInput('ano_tree', 'Choose the year', 
                                      min = min(base_crime$Ano),
                                      max = max(base_crime$Ano),
                                      value = max(base_crime$Ano),
                                      step = 1,
                                      animate = animationOptions(interval = 1750, loop = TRUE), sep=""),
                          
                          conditionalPanel(condition = ("input.tipo_dado_tree != 'pop_radio_tree'"),
                          selectInput('crime_tree', 'Choose a crime', 
                                      as.character(unique(base_crime$Crime)),
                                      selected = "Homicide")),
                          
                          radioButtons("tipo_dado_tree", "Information Type:",
                                       c("Number of Occurrences" = "ocorre_radio_tree",
                                         "Rate per 100,000 people" = "taxa_radio_tree",
                                         "Population" = "pop_radio_tree"))
                          
                        ),
                        
                        # Show the plots
                        mainPanel(
                          #d3plusOutput("tree_map")
						  uiOutput("tree_map")
                        )
                      )),
             tabPanel(id = "download", "Download Dataset",
                      
                      sidebarLayout(
                        sidebarPanel(
                          h2("Dataset Table"),
                          p("Search the information of your interest in the table beside."),
						  br(),
                          p("If you want to ", strong("download"), "the full dataset, click on the icon below."),
                          downloadButton('downloadData', 'Download .csv')
                        ),
                        
                        # Show the plots
                        mainPanel(
                          dataTableOutput("tabela")
                        )
                      )))
  
  # Sidebar
  
  # Fim do User Interface
)})